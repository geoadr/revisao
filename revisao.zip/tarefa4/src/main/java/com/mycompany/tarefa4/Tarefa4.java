/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tarefa4;

/**
 *
 * @author GeoDantas
 */
import java.util.Scanner;

class No {
    String txt;
    No ant;
    No prox;

    public No(String texto) {
        this.txt = txt;
        this.ant = null;
        this.prox = null;
    }
}

class EditorTexto {
    private No inicio;
    private No fim;
    private int tamanho;

    public EditorTexto() {
        inicio = null;
        fim = null;
        tamanho = 0;
    }

    public void inserirInicio(String texto) {
        No novo = new No(texto);

        if (inicio == null) {
            inicio = fim = novo;
        } else {
            novo.prox = inicio;
            inicio.ant = novo;
            inicio = novo;
        }
        tamanho++;
    }

    public void inserirFim(String texto) {
        No novo = new No(texto);

        if (fim == null) {
            inicio = fim = novo;
        } else {
            fim.prox = novo;
            novo.ant = fim;
            fim = novo;
        }
        tamanho++;
    }

    public void inserirPosicao(String texto, int posicao) {
        if (posicao < 1 || posicao > tamanho + 1) {
            System.out.println("posicao invalida");
            return;
        }

        if (posicao == 1) {
            inserirInicio(texto);
            return;
        }

        if (posicao == tamanho + 1) {
            inserirFim(texto);
            return;
        }

        No novo = new No(texto);
        No atual = inicio;

        for (int i = 1; i < posicao - 1; i++) {
            atual = atual.prox;
        }

        novo.prox = atual.prox;
        novo.ant = atual;
        atual.prox.ant = novo;
        atual.prox = novo;
        tamanho++;
    }

    public void remover(int posicao) {
        if (posicao < 1 || posicao > tamanho) {
            System.out.println("posicao invalida");
            return;
        }

        if (posicao == 1) { 
            inicio = inicio.prox;
            if (inicio != null)
                inicio.ant = null;
            else
                fim = null;
            tamanho--;
            return;
        }

        if (posicao == tamanho) { 
            fim = fim.ant;
            fim.prox = null;
            tamanho--;
            return;
        }

        No atual = inicio;
        for (int i = 1; i < posicao; i++) {
            atual = atual.prox;
        }

        atual.ant.prox = atual.prox;
        atual.prox.ant = atual.ant;
        tamanho--;
    }

    public void exibirFrente() {
        System.out.println("\n doc");
        No atual = inicio;
        int linha = 1;
        while (atual != null) {
            System.out.println(linha + ": " + atual.txt);
            atual = atual.prox;
            linha++;
        }
    }

    public void exibirTras() {
        System.out.println("\n doc 2");
        No atual = fim;
        int linha = tamanho;
        while (atual != null) {
            System.out.println(linha + ": " + atual.txt);
            atual = atual.ant;
            linha--;
        }
    }
}


public class    Tarefa4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        EditorTexto editor = new EditorTexto();

        int opcao;

        do {
            System.out.println("\n editor");
            System.out.println("1 colocar linha no início");
            System.out.println("2 colocar linha no fim");
            System.out.println("3 colocar linha em posição específica");
            System.out.println("4 tirar linha");
            System.out.println("5 exibir doc de frente");
            System.out.println("6 exibir doc de tras)");
            System.out.println("0 sair");
            System.out.print("escolha: ");
            opcao = sc.nextInt();
            sc.nextLine(); 

            switch (opcao) {
                case 1:
                    System.out.print("digite o texto da linha: ");
                    editor.inserirInicio(sc.nextLine());
                    break;

                case 2:
                    System.out.print("digite o texto da linha: ");
                    editor.inserirFim(sc.nextLine());
                    break;

                case 3:
                    System.out.print("digite o texto da linha: ");
                    String txt = sc.nextLine();
                    System.out.print("digite a posicao: ");
                    int pos = sc.nextInt();
                    sc.nextLine();
                    editor.inserirPosicao(txt, pos);
                    break;

                case 4:
                    System.out.print("digite a linha a remover: ");
                    int rem = sc.nextInt();
                    sc.nextLine();
                    editor.remover(rem);
                    break;

                case 5:
                    editor.exibirFrente();
                    break;

                case 6:
                    editor.exibirTras();
                    break;

                case 0:
                    System.out.println("the end");
                    break;

                default:
                    System.out.println("opção invalida");
            }

        } while (opcao != 0);

        sc.close();
    }
}
