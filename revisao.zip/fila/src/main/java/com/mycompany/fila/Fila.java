/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.fila;

/**
 *
 * @author GeoDantas
 */
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

class FilaB {
    private Queue<Integer> fila;

    public FilaB() {
        fila = new LinkedList<>();
    }

    public void enfileirar(int senha) {
        fila.add(senha);
        System.out.println("senha " + senha + " adicionada na fila.");
    }

    public Integer desenfileirar() {
        if (estaVazia()) {
            System.out.println("nenhum cliente na fila.");
            return null;
        }
        return fila.remove();
    }

    public Integer frente() {
        if (estaVazia()) {
            System.out.println("nenhum cliente na fila.");
            return null;
        }
        return fila.peek();
    }

    public int tamanho() {
        return fila.size();
    }

    public boolean estaVazia() {
        return fila.isEmpty();
    }
}

public class Fila {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        FilaB fila = new FilaB();
        int opcao;
        int senha = 1;

        do {
            System.out.println("\n sistema de stendimento bancsrio");
            System.out.println("1 adicionar cliente na fila");
            System.out.println("2 chamar proximo cliente");
            System.out.println("3 mostrar quantidade de clientes aguardando");
            System.out.println("4 mostrar proximo cliente");
            System.out.println("0 sair");
            System.out.print("opcao: ");
            opcao = sc.nextInt();

            switch (opcao) {
                case 1:
                    fila.enfileirar(senha++);
                    break;

                case 2:
                    Integer chamado = fila.desenfileirar();
                    if (chamado != null) {
                        System.out.println("chamando senha: " + chamado);
                    }
                    break;

                case 3:
                    System.out.println("cliente aguardando: " + fila.tamanho());
                    break;

                case 4:
                    Integer proximo = fila.frente();
                    if (proximo != null) {
                        System.out.println("proximo cliente: " + proximo);
                    }
                    break;

                case 0:
                    System.out.println("the end");
                    break;

                default:
                    System.out.println("opcao invalida");
            }
        } while (opcao != 0);

        sc.close();
    }
}

