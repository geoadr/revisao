/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tarefa5;

/**
 *
 * @author GeoDantas
 */
import java.util.Scanner;

class Doc {
    String nome;
    int pag;
    Doc prox;

    public Doc(String nome, int pag) {
        this.nome = nome;
        this.pag = pag;
        this.prox = null;
    }
}

class FilaImpressao {
    private Doc inicio;
    private Doc fim;

    public FilaImpressao() {
        inicio = null;
        fim = null;
    }

    public void adicionarDoc(String nome, int pag) {
        Doc novo = new Doc(nome, pag);

        if (inicio == null) { 
            inicio = fim = novo;
        } else {
            fim.prox = novo;
            fim = novo;
        }
        System.out.println("doc \"" + nome + "\" adicionado a fila.");
    }

    public void imprimirDoc() {
        if (inicio == null) {
            System.out.println("nenhum doc na fila.");
            return;
        }

        System.out.println("\n📄 imprimindo: " + inicio.nome + " (" + inicio.pag + " paginas)");
        inicio = inicio.prox;

        if (inicio == null) {
            fim = null;
        }
    }

    public void cancelarDoc(String nome) {
        if (inicio == null) {
            System.out.println("fila vazia.");
            return;
        }

        if (inicio.nome.equalsIgnoreCase(nome)) {
            inicio = inicio.prox;
            if (inicio == null)
                fim = null;
            System.out.println("doc \"" + nome + "\" foi cancelado.");
            return;
        }

        Doc atual = inicio;
        while (atual.prox != null && !atual.prox.nome.equalsIgnoreCase(nome)) {
            atual = atual.prox;
        }

        if (atual.prox == null) {
            System.out.println("doc nao encontrado.");
        } else {
            System.out.println("doc \"" + atual.prox.nome + "\" cancelado.");
            atual.prox = atual.prox.prox;

            if (atual.prox == null)
                fim = atual;
        }
    }

    public void mostrarFila() {
        if (inicio == null) {
            System.out.println("fila vazia.");
            return;
        }

        System.out.println("\n doc na fila ");
        Doc atual = inicio;
        int pos = 1;

        while (atual != null) {
            System.out.println(pos + " - " + atual.nome + " (" + atual.pag + " paginas)");
            atual = atual.prox;
            pos++;
        }
    }

    public int totalPaginas() {
        int total = 0;
        Doc atual = inicio;

        while (atual != null) {
            total += atual.pag;
            atual = atual.prox;
        }
        return total;
    }
}

public class Tarefa5 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        FilaImpressao fila = new FilaImpressao();
        int opcao;

        do {
            System.out.println("\n IMPRESSORA ");
            System.out.println("1 add doc");
            System.out.println("2 imprimir proximo doc");
            System.out.println("3 cancelar doc");
            System.out.println("4 mostrar fila de impressao");
            System.out.println("5 total de paginas na fila");
            System.out.println("0 sair");
            System.out.print("opção: ");
            opcao = sc.nextInt();
            sc.nextLine(); 

            switch (opcao) {
                case 1:
                    System.out.print("nome do documento: ");
                    String nome = sc.nextLine();
                    System.out.print("numero de paginas: ");
                    int pag = sc.nextInt();
                    fila.adicionarDoc(nome, pag);
                    break;

                case 2:
                    fila.imprimirDoc();
                    break;

                case 3:
                    System.out.print("nome do documento para cancelar: ");
                    String cancelar = sc.nextLine();
                    fila.cancelarDoc(cancelar);
                    break;

                case 4:
                    fila.mostrarFila();
                    break;

                case 5:
                    System.out.println("total de paginas aguardando: " + fila.totalPaginas());
                    break;

                case 0:
                    System.out.println("the end");
                    break;

                default:
                    System.out.println("opcao invalida.");
            }

        } while (opcao != 0);

        sc.close();
    }
}
