/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pilha;

/**
 *
 * @author GeoDantas
 */

import java.util.Scanner;

// Classe da estrutura de pilha (NÃO pública)
class PilhaDecimal {
    private int[] element;
    private int topo;

    public PilhaDecimal(int capacidade) {
        element = new int[capacidade];
        topo = -1;
    }

    public void empilha(int valor) {
        if (topo == element.length - 1) {
            System.out.println("pilha lotada, nao da para empilhar.");
            return;
        }
        element[++topo] = valor;
    }

    public int desempilha() {
        if (estaVazia()) {
            System.out.println("pilha vazia");
            return -1;
        }
        return element[topo--];
    }

    public int topo() {
        if (estaVazia()) {
            System.out.println("pilha vazia");
            return -1;
        }
        return element[topo];
    }

    public boolean estaVazia() {
        return topo == -1;
    }
}

public class Pilha {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("digite um numero inteiro positivo: ");
        int n = sc.nextInt();

        if (n <= 0) {
            System.out.println("o numero deve ser maior que zero.");
            return;
        }

        PilhaDecimal pilha = new PilhaDecimal(32);

        int num = n;

        while (num > 0) {
            int resto = num % 2;
            pilha.empilha(resto);
            num /= 2;
        }

        System.out.print("representação binaria de " + n + ": ");
        while (!pilha.estaVazia()) {
            System.out.print(pilha.desempilha());
        }

        System.out.println(); 
        sc.close();
    }
}
