/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tarefa7;

/**
 *
 * @author GeoDantas
 */

import java.util.Scanner;

class Carta {
    String valor;
    Carta ant;
    Carta prox;

    public Carta(String valor) {
        this.valor = valor;
        this.ant = null;
        this.prox = null;
    }
}

class DequeCartas {
    private Carta inicio;
    private Carta fim;

    public DequeCartas() {
        inicio = null;
        fim = null;
    }

    public boolean estaVazio() {
        return inicio == null;
    }

    public void inserirInicio(String valor) {
        Carta nova = new Carta(valor);

        if (estaVazio()) {
            inicio = fim = nova;
        } else {
            nova.prox = inicio;
            inicio.ant = nova;
            inicio = nova;
        }
        System.out.println("carta inserida no inicio: " + valor);
    }

    public void inserirFim(String valor) {
        Carta nova = new Carta(valor);

        if (estaVazio()) {
            inicio = fim = nova;
        } else {
            fim.prox = nova;
            nova.ant = fim;
            fim = nova;
        }
        System.out.println("carta inserida no fim: " + valor);
    }

    public String removerInicio() {
        if (estaVazio()) {
            System.out.println("deque vaziooo.");
            return null;
        }

        String valor = inicio.valor;

        if (inicio == fim) { 
            inicio = fim = null;
        } else {
            inicio = inicio.prox;
            inicio.ant = null;
        }

        System.out.println("carta removida do inicio: " + valor);
        return valor;
    }

    public String removerFim() {
        if (estaVazio()) {
            System.out.println("deque vazioooo.");
            return null;
        }

        String valor = fim.valor;

        if (inicio == fim) {
            inicio = fim = null;
        } else {
            fim = fim.ant;
            fim.prox = null;
        }

        System.out.println("carta removida do fim: " + valor);
        return valor;
    }

    public void frente() {
        if (estaVazio()) {
            System.out.println("deque vazioooo.");
        } else {
            System.out.println("primeira carta: " + inicio.valor);
        }
    }

    public void tras() {
        if (estaVazio()) {
            System.out.println("deque vaziooo.");
        } else {
            System.out.println("ultima carta: " + fim.valor);
        }
    }
    public void inverter() {
        if (estaVazio()) {
            System.out.println("deque vaziooo.");
            return;
        }

        Carta atual = inicio;
        Carta temp = null;

        while (atual != null) {
            temp = atual.ant;
            atual.ant = atual.prox;
            atual.prox = temp;
            atual = atual.ant;
        }

     
        temp = inicio;
        inicio = fim;
        fim = temp;

        System.out.println("deque invertido.");
    }

    public void exibir() {
        if (estaVazio()) {
            System.out.println("deque vazioooo.");
            return;
        }

        System.out.println("\ncartas");

        Carta atual = inicio;
        while (atual != null) {
            System.out.println(atual.valor);
            atual = atual.prox;
        }
    }
}

public class Tarefa7 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        DequeCartas deque = new DequeCartas();
        int opcao;

        do {
            System.out.println("\nJOGO DE CARTAS (");
            System.out.println("1 inserir carta la no inicio");
            System.out.println("2 inserir carta la no fim");
            System.out.println("3 remover carta la do inicio");
            System.out.println("4 remover carta la do fim");
            System.out.println("5 comprar carta do inicio");
            System.out.println("6 descartar carta no fim");
            System.out.println("7 inverter o deque)");
            System.out.println("8 ver primeira carta");
            System.out.println("9 ver ultima carta");
            System.out.println("10 exibir todas as cartas");
            System.out.println("0 sair");
            System.out.print("opcao: ");
            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1:
                    System.out.print("digite o nome da carta: ");
                    deque.inserirInicio(sc.nextLine());
                    break;

                case 2:
                    System.out.print("digite o nome da carta: ");
                    deque.inserirFim(sc.nextLine());
                    break;

                case 3:
                    deque.removerInicio();
                    break;

                case 4:
                    deque.removerFim();
                    break;

                case 5: 
                    String comprada = deque.removerInicio();
                    if (comprada != null) {
                        System.out.println("vc comprou: " + comprada);
                    }
                    break;

                case 6: 
                    System.out.print("Digite a carta a descartar: ");
                    deque.inserirFim(sc.nextLine());
                    break;

                case 7:
                    deque.inverter();
                    break;

                case 8:
                    deque.frente();
                    break;

                case 9:
                    deque.tras();
                    break;

                case 10:
                    deque.exibir();
                    break;

                case 0:
                    System.out.println("the end");
                    break;

                default:
                    System.out.println("opcao invalida.");
            }

        } while (opcao != 0);

        sc.close();
    }
}
