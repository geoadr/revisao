/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tarefa3;

/**
 *
 * @author GeoDantas
 */

import java.util.Scanner;

public class Tarefa3 {

    public static int somaD(int n) {
        if (n < 10) {
            return n;
        }
        
        return (n % 10) + somaD(n / 10);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("digite um nimero inteiro nao negativo: ");
        int n = sc.nextInt();

        if (n < 0) {
            System.out.println("o numero tem q ser nao negativo.");
            return;
        }

        int resultado = somaD(n);

        System.out.println("soma dos digitos de " + n + " = " + resultado);
        
        sc.close();
    }
}
