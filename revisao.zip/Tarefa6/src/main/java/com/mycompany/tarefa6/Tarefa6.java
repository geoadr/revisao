/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tarefa6;

/**
 *
 * @author GeoDantas
 */

import java.util.Scanner;
class pag {
    String url;
    pag anterior;

    public pag(String url) {
        this.url = url;
        this.anterior = null;
    }
}
class PilhaHistorico {
    private pag topo;

    public PilhaHistorico() {
        topo = null;
    }

    public void visitarpag(String url) {
        pag nova = new pag(url);
        nova.anterior = topo;
        topo = nova;

        System.out.println("pagina visitada: " + url);
    }

    public void voltarpag() {
        if (topo == null) {
            System.out.println("Nnao ha paginas no historico.");
            return;
        }

        System.out.println("voltando de: " + topo.url);
        topo = topo.anterior;
    }

    public void paginaAtual() {
        if (topo == null) {
            System.out.println("nenhuma pagina aberta.");
        } else {
            System.out.println("Pagina atual: " + topo.url);
        }
    }

    public void mostrarHistorico() {
        if (topo == null) {
            System.out.println("historico vazio.");
            return;
        }

        System.out.println("\n historico");
        pag atual = topo;
        int pos = 1;

        while (atual != null) {
            System.out.println(pos + " - " + atual.url);
            atual = atual.anterior;
            pos++;
        }
    }

    public void limparHistorico() {
        topo = null;
        System.out.println("historico completamente limpo.");
    }
}

public class Tarefa6 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PilhaHistorico historico = new PilhaHistorico();
        int opcao;

        do {
            System.out.println("\n NAVEGAÇÃO WEB");
            System.out.println("1 visitar nova pagina");
            System.out.println("2 voltar pagina");
            System.out.println("3 mostrar pagina atual");
            System.out.println("4 exibir historico completo");
            System.out.println("5 limpar historico");
            System.out.println("0 sair");
            System.out.print("opcao: ");
            opcao = sc.nextInt();
            sc.nextLine(); 

            switch (opcao) {
                case 1:
                    System.out.print("digite  URL: ");
                    String url = sc.nextLine();
                    historico.visitarpag(url);
                    break;

                case 2:
                    historico.voltarpag();
                    break;

                case 3:
                    historico.paginaAtual();
                    break;

                case 4:
                    historico.mostrarHistorico();
                    break;

                case 5:
                    historico.limparHistorico();
                    break;

                case 0:
                    System.out.println("the end");
                    break;

                default:
                    System.out.println("opcao invalida.");
            }

        } while (opcao != 0);

        sc.close();
    }
}

